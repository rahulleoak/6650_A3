import com.google.gson.Gson;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DeliverCallback;
import com.rabbitmq.client.Delivery;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
public class ReviewConsumer implements Runnable{
  private Channel channel;
  private final String queueName;
  private DynamoDbClient dynamoDb;
  private final String tableName = "album"; // Change to your DynamoDB table name
  private final String AWS_ACCESS_KEY_ID="ASIARZC6LZUT2MNWRFZP";
  private final String AWS_SECRET_ACCESS_KEY="syeorE96DAaa6uokkzlsBCRNVZYh/Q/BtmI9luDW";
  private final String AWS_SESSION_TOKEN="FwoGZXIvYXdzENz//////////wEaDMjxBwz7GC4cNPVOoCLNAVH46uTYMcGiz6UfVzxC838AAYE69TCPtcfBRwzSAbFJA2ciAs7EoGAa2w33PLHp5alAP+ZfVz9avm7lm7nD2C8F7t9ndqEX4BKK5uIutXcCWfxYqqZbui7qfVHKNtiqpG4l2I/neH8On2OoNkJ6qZBHyqA3hWO8B7vKoGihRGzvl5lBgIxJ3zLPAP89EAaWVfVkyDzC1Dcd6XNyyYICC5EDBGK0gsSyg9qgUhRL/ZfwgMQ6oaPuAPYE1dP3h0pdEjBOHxGkiT9TbLwe1V8oiPStqwYyLeHX3hKKC0I3j4lbEzm1RcAIozTQEqMQfy8uQP99vjNEJZDoBWDPy+M1t0pOgw==";

  public ReviewConsumer(String queueName) throws Exception {
    this.queueName = queueName;
    this.channel = RabbitMqChannelPool.borrowChannel();

    // Initialize DynamoDB client
    this.dynamoDb = DynamoDbClient.builder()
        .region(Region.US_WEST_2) // Change to your preferred region
        .credentialsProvider(StaticCredentialsProvider.create(
            AwsSessionCredentials.create(AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN)))
        .build();
  }



  @Override
  public void run() {

    try {
      channel.exchangeDeclare("reviewExchange","direct",false);
      channel.queueDeclare(queueName,true,false,false,null);
      channel.queueBind(queueName,"reviewExchange","");
//      channel.basicQos(1);
      DeliverCallback deliverCallback = this::handleDelivery;
      channel.basicConsume(queueName,true,deliverCallback,consumerTag -> {});
      System.out.println("memes");

    } catch (IOException e) {
      throw new RuntimeException(e);
    } finally {
      closeChannel();
    }
    //2nd edit
//      channel.exchangeDeclare("reviewExchange","direct",false);
//      channel.queueDeclare("reviews", true, false, false, null);
//      channel.queueBind("reviews","reviewExchange","");
//      DeliverCallback deliverCallback = this::handleDelivery;
//
//      channel.basicConsume(queueName, true, deliverCallback, consumerTag -> {});
//    } catch (Exception e) {
//      e.printStackTrace();
//      // Handle exception (logging, alerting, etc.)
//    }
    //1st edit
//      channel.queueDeclare(queueName, true, false, false, null);
//      DeliverCallback deliverCallback = (consumerTag, delivery) -> {
//        String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
//        Review review = new Gson().fromJson(message, Review.class);
//        // Process the review
//        processReview(review);
//      };
//      channel.basicConsume(queueName, true, deliverCallback, consumerTag -> {});
//    } catch (Exception e) {
//      e.printStackTrace();
//      // Handle exception
//    }
  }

  private void handleDelivery(String consumerTag, Delivery delivery) {
    System.out.println("Delivery Start");
    String message = new String(delivery.getBody(), StandardCharsets.UTF_8);
    String[] URLSplit  = message.split(":");
    String reviewType = URLSplit[0];
    String albumID = URLSplit[1];
    processReview(reviewType,albumID);
    System.out.println("Delivery done");
  }

  private void processReview(String reviewType, String albumID) {
//    try {
//      Map<String, AttributeValue> key = new HashMap<>();
//      key.put("albumID", AttributeValue.builder().s(String.valueOf(albumID)).build());

      String updateExpression;
      Map<String, AttributeValue> expressionAttributeValues = new HashMap<>();

      if (reviewType.equals("like")) {
        updateExpression = "set likeCount = if_not_exists (likeCount,:start) + :val";
      } else {
        updateExpression = "set dislikeCount = if_not_exists (dislikeCount,:start) + :val";
      }

      expressionAttributeValues.put(":val", AttributeValue.builder().n("1").build());
      expressionAttributeValues.put(":start", AttributeValue.builder().n("0").build());

      UpdateItemRequest updateRequest = UpdateItemRequest.builder()
          .tableName(tableName)
//          .key(key)
          .key(Collections.singletonMap("albumID",AttributeValue.builder().s(albumID).build()))
          .updateExpression(updateExpression)
          .expressionAttributeValues(expressionAttributeValues)
          .build();

      dynamoDb.updateItem(updateRequest);
//    } catch (DynamoDbException e) {
//      e.printStackTrace();
//      // Handle DynamoDB exception
//    }
  }


  public void closeChannel() {
    try {
      if (channel != null && channel.isOpen()) {
        RabbitMqChannelPool.returnChannel(channel);
      }
    } catch (Exception e) {
      e.printStackTrace();
      // Handle closing exception
    }
  }

}
