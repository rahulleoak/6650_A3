public class Review {
  private String albumID;
  private String reviewType;

  public Review(String albumID, String reviewType) {
    this.albumID = albumID;
    this.reviewType = reviewType;
  }

  public String getAlbumID() {
    return albumID;
  }

  public String getReviewType() {
    return reviewType;
  }
}
